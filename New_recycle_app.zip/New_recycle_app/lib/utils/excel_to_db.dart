import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class ExcelToDb {
  Future<void> importExcelToDatabase(String filePath) async {
    final file = File(filePath);
    final bytes = file.readAsBytesSync();
    final excel = Excel.decodeBytes(bytes);

    // 데이터베이스 경로 설정
    final directory = await getApplicationDocumentsDirectory();
    final dbPath = join(directory.path, 'products.db');

    // 데이터베이스 초기화
    final database = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute(
          'CREATE TABLE products(id INTEGER PRIMARY KEY, barcode TEXT, name TEXT, material TEXT)',
        );
      },
    );

    // 엑셀 데이터를 데이터베이스로 변환
    for (var table in excel.tables.keys) {
      for (var row in excel.tables[table]!.rows.skip(1)) {
        final barcode = row[0]?.value.toString() ?? '';
        final name = row[1]?.value.toString() ?? '';
        final material = row[2]?.value.toString() ?? '';

        final product = {
          'barcode': barcode,
          'name': name,
          'material': material,
        };

        await database.insert('products', product, conflictAlgorithm: ConflictAlgorithm.replace);
      }
    }
  }
}
