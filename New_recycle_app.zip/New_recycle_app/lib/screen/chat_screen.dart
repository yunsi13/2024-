import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ChatScreen extends StatefulWidget {
  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final List<String> _messages = [];
  final String _apiKey = 'sk-proj-HzYTpiTuKRLhKAhc2mFFT3BlbkFJm45VEnXAZQtI78Bc9Kjw';

  Future<String> _sendMessage(String message) async {
    final url = Uri.parse('https://api.openai.com/v1/engines/davinci-codex/completions');
    final response = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $_apiKey',
      },
      body: json.encode({
        'prompt': message,
        'max_tokens': 50,
      }),
    );

    final body = json.decode(response.body);
    return body['choices'][0]['text'];
  }

  void _handleSend() async {
    final message = _controller.text;
    if (message.isNotEmpty) {
      setState(() {
        _messages.add('You: $message');
      });
      _controller.clear();
      final response = await _sendMessage(message);
      setState(() {
        _messages.add('Bot: $response');
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat with Bot'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) => ListTile(
                title: Text(_messages[index]),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(hintText: 'Enter message'),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: _handleSend,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
