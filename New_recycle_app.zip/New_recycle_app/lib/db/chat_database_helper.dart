import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class ChatDatabaseHelper {
  static final ChatDatabaseHelper _instance = ChatDatabaseHelper._internal();
  factory ChatDatabaseHelper() => _instance;
  ChatDatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'chat.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute(
      'CREATE TABLE chats(id INTEGER PRIMARY KEY, message TEXT, is_user_message INTEGER)',
    );
  }

  Future<void> insertChatMessage(String message, bool isUserMessage) async {
    final db = await database;
    await db.insert('chats', {
      'message': message,
      'is_user_message': isUserMessage ? 1 : 0,
    });
  }

  Future<List<Map<String, dynamic>>> getChatMessages() async {
    final db = await database;
    return await db.query('chats');
  }
}
