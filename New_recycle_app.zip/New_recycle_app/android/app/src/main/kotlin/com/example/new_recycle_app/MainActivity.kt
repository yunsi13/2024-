package com.example.new_recycle_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
