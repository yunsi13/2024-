package com.example.recycle_hepler_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
