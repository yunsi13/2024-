import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/chatbot');
              },
              child: const Text('Chat with Chatbot'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/barcode_scanner');
              },
              child: const Text('Scan Barcode'),
            ),
          ],
        ),
      ),
    );
  }
}
