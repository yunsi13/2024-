import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show kIsWeb, defaultTargetPlatform, TargetPlatform;
import 'package:flutter/material.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      default:
        throw UnsupportedError('DefaultFirebaseOptions are not supported for this platform.');
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyC2NwY8lLdYPp01avkbOxIavVCUCePN27M',
    authDomain: 'my-application-636d6.firebaseapp.com',
    projectId: 'my-application-636d6',
    storageBucket: 'my-application-636d6.appspot.com',
    messagingSenderId: '227070976674',
    appId: 'YOUR_APP_ID', // 실제 App ID로 대체해야 합니다.
    measurementId: 'YOUR_MEASUREMENT_ID', // 필요한 경우 실제 Measurement ID로 대체해야 합니다.
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyC2NwY8lLdYPp01avkbOxIavVCUCePN27M',
    authDomain: 'my-application-636d6.firebaseapp.com',
    projectId: 'my-application-636d6',
    storageBucket: 'my-application-636d6.appspot.com',
    messagingSenderId: '227070976674',
    appId: 'YOUR_APP_ID', // 실제 App ID로 대체해야 합니다.
    measurementId: 'com.recycle-helper-app', // 필요한 경우 실제 Measurement ID로 대체해야 합니다.
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyC2NwY8lLdYPp01avkbOxIavVCUCePN27M',
    authDomain: 'my-application-636d6.firebaseapp.com',
    projectId: 'my-application-636d6',
    storageBucket: 'my-application-636d6.appspot.com',
    messagingSenderId: '227070976674',
    appId: 'YOUR_APP_ID', // 실제 App ID로 대체해야 합니다.
    iosBundleId: 'com.recycle-helper-app', // 실제 iOS 번들 ID로 대체해야 합니다.
  );

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyC2NwY8lLdYPp01avkbOxIavVCUCePN27M',
    authDomain: 'my-application-636d6.firebaseapp.com',
    projectId: 'my-application-636d6',
    storageBucket: 'my-application-636d6.appspot.com',
    messagingSenderId: '227070976674',
    appId: 'YOUR_APP_ID', // 실제 App ID로 대체해야 합니다.
    iosBundleId: 'com.recycle-helper-app', // 실제 iOS 번들 ID로 대체해야 합니다.
  );
}
