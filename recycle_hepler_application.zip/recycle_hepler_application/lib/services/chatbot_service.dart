import 'dart:convert';
import 'package:http/http.dart' as http;

class ChatbotService {
  Future<String> sendMessage(String message) async {
    try {
      final response = await http.post(
        Uri.parse('https://your-chatbot-api-endpoint.com/message'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'message': message}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['response'];
      } else {
        print('Failed to load chatbot response: ${response.statusCode}');
        return 'Error: ${response.statusCode}';
      }
    } catch (e) {
      print('Exception caught: $e');
      return 'Error: $e';
    }
  }
}
