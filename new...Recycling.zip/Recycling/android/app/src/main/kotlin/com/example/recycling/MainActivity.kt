package com.example.recycling

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
