import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'auth_provider.dart';
import 'auth_wrapper.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: FirebaseOptions(
        apiKey: 'AIzaSyDxjPpqjbQtVc9WVVJCFMYSEofcSUrF-Jk',
        messagingSenderId: '597732530221',
        authDomain: "neww-56a26.firebaseapp.com",
        projectId: 'neww-56a26',
        storageBucket: "neww-56a26.appspot.com",
        appId: "1:597732530221:android:5e531aaa1bd32c7abac0a4"
    ),
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AuthProvider(),
      child: MaterialApp(
        title: 'Recycling App',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: AuthWrapper(),
      ),
    );
  }
}
