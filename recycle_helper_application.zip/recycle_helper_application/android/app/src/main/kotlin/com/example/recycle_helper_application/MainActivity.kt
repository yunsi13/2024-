package com.example.recycle_helper_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
