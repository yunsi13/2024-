import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Welcome to the Recycle Helper Application!'),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/barcode');
              },
              child: Text('Scan Barcode'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/chatbot');
              },
              child: Text('Chat with Bot'),
            ),
          ],
        ),
      ),
    );
  }
}
