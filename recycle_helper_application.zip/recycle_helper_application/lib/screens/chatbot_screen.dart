import 'package:flutter/material.dart';
import 'package:recycle_helper_application/services/chatbot_service.dart';

class ChatbotScreen extends StatefulWidget {
  final String apiKey;

  const ChatbotScreen({required this.apiKey, Key? key}) : super(key: key);

  @override
  _ChatbotScreenState createState() => _ChatbotScreenState();
}

class _ChatbotScreenState extends State<ChatbotScreen> {
  final TextEditingController _controller = TextEditingController();
  late ChatbotService _chatbotService;
  List<Map<String, String>> _messages = [];

  @override
  void initState() {
    super.initState();
    _chatbotService = ChatbotService(apiKey: widget.apiKey);
  }

  void _sendMessage() async {
    final message = _controller.text;
    if (message.isEmpty) {
      return;
    }
    setState(() {
      _messages.add({'role': 'user', 'content': message});
    });
    _controller.clear();

    try {
      final response = await _chatbotService.sendMessage(message);
      setState(() {
        _messages.add({'role': 'assistant', 'content': response});
      });
    } catch (e) {
      setState(() {
        _messages.add({'role': 'assistant', 'content': 'Failed to get response from chatbot: $e'});
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chatbot'),
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: ListView.builder(
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                return ListTile(
                  title: Text(message['content']!),
                  subtitle: Text(message['role']!),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(hintText: 'Enter your message'),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: _sendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
